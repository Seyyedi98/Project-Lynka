/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ["arklight.storage.c2.liara.space", "c465756.parspack.net"],
  },
};

export default nextConfig;
