/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ["arklight.storage.c2.liara.space"],
  },
};

export default nextConfig;
