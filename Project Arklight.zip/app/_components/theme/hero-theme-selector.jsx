import useFilterTheme from "@/hooks/useFilterTheme";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import SquareButton from "../common/button/square-button";
import { HeroController } from "../controller/hero-controller";

const HeroThemeSelector = () => {
  const dispatch = useDispatch();
  const hero = useSelector((state) => state.page.hero);

  const [themeCategory, setThemeCategory] = useState("color"); // color || pattern || gradient || image

  const Themes = HeroController;
  if (!Themes) throw new Error("Cannot load hero themes");

  const filteredThemesList = useFilterTheme(Themes, themeCategory);

  return (
    <div>
      <div className="mb-4 mt-0 flex w-full items-center justify-between gap-2">
        <SquareButton
          action={setThemeCategory}
          state={themeCategory}
          rule="color"
        >
          رنگ
        </SquareButton>
        <SquareButton
          action={setThemeCategory}
          state={themeCategory}
          rule="pattern"
        >
          الگو
        </SquareButton>
        <SquareButton
          action={setThemeCategory}
          state={themeCategory}
          rule="gradient"
        >
          گرادیانت
        </SquareButton>
        <SquareButton
          action={setThemeCategory}
          state={themeCategory}
          rule="image"
        >
          تصویر
        </SquareButton>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2">
        {filteredThemesList.map((theme, index) => {
          return (
            <div
              key={(index, theme)}
              onClick={() => {
                dispatch({
                  type: "page/setHero",
                  payload: {
                    ...hero,
                    extraAttributes: {
                      ...hero.extraAttributes,
                      style: theme[0],
                    },
                  },
                });
                dispatch({ type: "modal/closeMenu" });
              }}
            >
              {theme[0]}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default HeroThemeSelector;
