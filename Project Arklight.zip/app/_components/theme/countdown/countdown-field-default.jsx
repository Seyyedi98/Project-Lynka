import React from "react";
import ShiftingCountdown from "../../common/countdown";

const CountdownFieldDefault = (props) => {
  return <ShiftingCountdown {...props} />;
};

export default CountdownFieldDefault;
