import { useState } from "react";
import SquareButton from "../../common/button/square-button";
import { useDispatch, useSelector } from "react-redux";
import { cn } from "@/lib/utils";
import { colors, gradient, pattern } from "@/data/colors";
import { Input } from "@/components/ui/input";
import PageBgImageForm from "../../common/form/page-bg-image-form";
import deleteFile from "@/lib/upload/deleteFile";

const PageBackgroundSettings = () => {
  const [category, setCategory] = useState("color");
  const theme = useSelector((store) => store.page.theme);

  const dispatch = useDispatch();

  const setPageBackground = function (velue) {
    const payload = {
      ...theme,
      backgroundColor: velue,
      backgroundType: "color",
    };
    dispatch({ type: "page/setTheme", payload });
  };

  return (
    <>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-4 border-b-2 pb-2 md:gap-[10px]">
        <SquareButton state={category} action={setCategory} rule="color">
          رنگ
        </SquareButton>
        <SquareButton state={category} action={setCategory} rule="gradient">
          طیف رنگی
        </SquareButton>
        <SquareButton state={category} action={setCategory} rule="pattern">
          الگو
        </SquareButton>
        <SquareButton state={category} action={setCategory} rule="image">
          تصویر
        </SquareButton>
      </div>
      <div className="grid h-[60svh] w-full max-w-sm grid-cols-[repeat(auto-fit,minmax(80px,1fr))] place-items-center gap-4 overflow-y-scroll [scrollbar-width:none] md:h-[80vh] md:max-h-full">
        {category === "color" && (
          <>
            <div className="col-span-full my-2 block w-full">
              <p className="mb-4 text-xs text-textLight">
                رنگ دلخواه خود را انتخاب کنید
              </p>
              <Input
                type="color"
                defaultValue={
                  theme?.backgroundType === "color"
                    ? theme?.backgroundColor
                    : "#FFFFFF"
                }
                onChange={(e) => setPageBackground(e.target.value)}
              />
            </div>

            {colors.map((color) => (
              <div
                key={color}
                style={{ backgroundColor: color }}
                onClick={() => setPageBackground(color)}
                className={cn(
                  `h-20 w-20 cursor-pointer rounded-full border border-primary duration-200 hover:shadow-xl`,
                  theme.backgroundColor === color && "border-4",
                )}
              ></div>
            ))}
          </>
        )}

        {category === "gradient" &&
          gradient.map((color) => {
            return (
              <div
                key={color}
                style={{ background: color }}
                onClick={() => setPageBackground(color)}
                className={cn(
                  `h-20 w-20 cursor-pointer rounded-full border border-primary duration-200 [scrollbar-width:none] hover:shadow-xl`,
                  theme.backgroundColor === color && "border-4",
                )}
              ></div>
            );
          })}

        {category === "pattern" &&
          pattern.map((color, index) => {
            return (
              <div
                key={index}
                style={{ background: color }}
                onClick={() => setPageBackground(color)}
                className={cn(
                  `h-20 w-20 cursor-pointer rounded-full border border-primary duration-200 [scrollbar-width:none] hover:shadow-xl`,
                  theme.backgroundColor === color && "border-4",
                )}
              ></div>
            );
          })}

        {category === "image" && (
          <div className="h-full">
            <PageBgImageForm
              theme={theme}
              bgType={theme.backgroundType}
              image={theme.backgroundColor}
            />
          </div>
        )}
      </div>
    </>
  );
};

export default PageBackgroundSettings;
