import React from "react";
import ThemeSwitcher from "../../common/button/ThemeSwitcher";

const WorkspaceSettings = () => {
  return (
    <div>
      <ThemeSwitcher />
    </div>
  );
};

export default WorkspaceSettings;
