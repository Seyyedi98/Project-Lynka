import { DragOverlay, useDndMonitor } from "@dnd-kit/core";
import { restrictToVerticalAxis } from "@dnd-kit/modifiers";
import { useState } from "react";
import { shallowEqual, useSelector } from "react-redux";
import { PageElements } from "../../controller/page-elements";
import { AdderBtnDragOverly } from "./add-element-button";

const DragOverlyWrapper = () => {
  const elements = useSelector((state) => state.page.elements, shallowEqual);
  const [draggedItem, setDraggedItem] = useState();

  useDndMonitor({
    onDragStart: (event) => {
      setDraggedItem(event.active);
    },
    onDragCancel: () => {
      setDraggedItem(null);
    },
    onDragEnd: () => {
      setDraggedItem(null);
    },
  });

  if (!draggedItem) return null;

  let node = <div>No drag overly</div>;
  const isSidebarBtnElement = draggedItem.data?.current?.isAdderBtn;

  // Overlay when drag sidebar adder button to workspace
  if (isSidebarBtnElement) {
    const type = draggedItem.data?.current?.type;
    node = <AdderBtnDragOverly pageElement={PageElements[type]} />;
  }

  const isWorkspaceElement = draggedItem.data?.current.isWorkspaceElement;

  // Overlay when drag elements inside workspace
  if (isWorkspaceElement) {
    const elementId = draggedItem.data?.current.elementId;
    const element = elements.find((el) => el.id === elementId);

    if (!element) {
      node = <div>Element not found!</div>;
    } else {
      const WorkspaceElementComponent =
        PageElements[element.type].WorkspaceComponent;
      node = (
        <div className="border-rounded-xl pointer-events-none flex w-full bg-transparent px-4 py-2 opacity-80">
          <WorkspaceElementComponent elementInstance={element} />
        </div>
      );
    }
  }

  // Dynamically determine modifiers based on the group
  const modifiers = isSidebarBtnElement ? [] : [restrictToVerticalAxis];

  return <DragOverlay modifiers={modifiers}>{node}</DragOverlay>;
};

export default DragOverlyWrapper;
