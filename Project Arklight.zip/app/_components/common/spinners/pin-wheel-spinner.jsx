import { LoaderPinwheel } from "lucide-react";
import React from "react";

const PinWheelSpinner = () => {
  return <LoaderPinwheel />;
};

export default PinWheelSpinner;
