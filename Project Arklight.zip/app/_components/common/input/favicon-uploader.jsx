import { UpdatePageFavicon } from "@/actions/page/page";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import deleteFile from "@/lib/upload/deleteFile";
import uploadFile from "@/lib/upload/uploadFile";
import getImageAddress from "@/utils/get-image-address";
import { Check, ImageIcon, Loader2, Trash2, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import toast from "react-hot-toast";
import { useDispatch, useSelector } from "react-redux";

const FaviconUploader = ({ uri, favicon }) => {
  const [file, setFile] = useState(null);
  const [error, setError] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [hasFavicon, setHasFavicon] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const fileInputRef = useRef(null);

  const dispatch = useDispatch();
  const metadata = useSelector((store) => store.page.metadata);

  const previousImage = favicon && getImageAddress(JSON.parse(favicon).key);

  const ACCESSKEY = process.env.NEXT_PUBLIC_ACCESS_KEY;
  const SECRETKEY = process.env.NEXT_PUBLIC_SECRET_KEY;
  const ENDPOINT = process.env.NEXT_PUBLIC_ENDPOINT;
  const BUCKET = process.env.NEXT_PUBLIC_BUCKET_NAME;

  // Set initial state from favicon prop
  useEffect(() => {
    setHasFavicon(!!favicon);
  }, [favicon]);

  const handleFileChange = async (event) => {
    const selectedFile = event.target.files[0];
    if (!selectedFile) return;

    setFile(selectedFile);
    setError(null);

    // Automatically start upload
    await handleUpload(selectedFile);
  };

  const handleUpload = async (fileToUpload) => {
    const options = {
      maxSizeMB: 0.1,
      maxWidthOrHeight: 32,
      initialQuality: 1,
      useWebWorker: true,
    };

    setIsUploading(true);

    try {
      const { permanentSignedUrl, response } = await uploadFile(
        fileToUpload,
        options,
      );
      const JSONFaviconData = JSON.stringify({
        key: response.Key,
      });

      await UpdatePageFavicon(uri, JSONFaviconData);

      const payload = {
        ...metadata,
        favicon: JSONFaviconData,
      };

      dispatch({ type: "page/setMetadata", payload });
      dispatch({ type: "modal/closeMenu" });
      toast.success("آیکون با موفقیت تغییر یافت");

      setHasFavicon(true);
    } catch (error) {
      toast.error("خطایی رخ داد. لطفا مجددا سعی کنید");

      console.log(error);
      setError("خطا در آپلود فاویکون");
    } finally {
      setIsUploading(false);
    }
  };

  const handleDelete = async () => {
    const file = favicon ? { key: JSON.parse(favicon).key } : null;

    setIsUploading(true);
    try {
      if (favicon) {
        await deleteFile({
          file: file,
          BUCKET,
          ACCESSKEY,
          SECRETKEY,
          ENDPOINT,
        });
      }

      await UpdatePageFavicon(uri, null);

      const payload = {
        ...metadata,
        favicon: null,
      };

      dispatch({ type: "page/setMetadata", payload });
      dispatch({ type: "modal/closeMenu" });
      toast.success("فاویکون با موفقیت حذف شد");

      setHasFavicon(false);
      setShowDeleteConfirm(false);
    } catch (error) {
      toast.error("خطایی در حذف فاویکون رخ داد");

      console.log(error);
    } finally {
      setIsUploading(false);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current.click();
  };

  return (
    <div className="upload-container">
      {isUploading && (
        <div className="fixed right-0 top-0 z-[99999] grid h-screen w-screen cursor-wait place-content-center bg-black opacity-80">
          <span className="flex items-center justify-center gap-2">
            در حال بارگزاری <Loader2 className="mt-1 animate-spin" />
          </span>
        </div>
      )}

      <div className="file-upload text-nowrap">
        {/* Hidden file input */}
        <Input
          id="favicon-uploader"
          ref={fileInputRef}
          type="file"
          onChange={handleFileChange}
          className="hidden"
          accept=".ico,image/vnd.microsoft.icon,image/x-icon,image/png,image/svg+xml"
        />

        {/* Only show upload area if there's no favicon */}
        {!hasFavicon && (
          <div
            onClick={triggerFileInput}
            className="mt-2 flex h-32 w-full cursor-pointer flex-col items-center justify-center rounded-md border-4 border-dashed border-gray-300 transition-colors duration-200 hover:border-gray-400 dark:border-white/30 dark:hover:border-white/50"
          >
            {isUploading ? (
              <Loader2 className="h-10 w-10 animate-spin text-gray-400" />
            ) : (
              <>
                <ImageIcon className="h-10 w-10 text-gray-400" />
                <span className="mt-2 text-sm text-gray-500">
                  انتخاب فاویکون
                </span>
              </>
            )}
          </div>
        )}

        {/* Show delete button if there's a favicon */}
        {hasFavicon && (
          <div className="mt-2">
            {showDeleteConfirm ? (
              <div className="flex w-full gap-2">
                <Button
                  variant="outline"
                  className="flex-1 gap-1"
                  onClick={(e) => {
                    e.preventDefault();
                    setShowDeleteConfirm(false);
                  }}
                  disabled={isUploading}
                >
                  <X className="h-4 w-4" />
                  انصراف
                </Button>
                <Button
                  variant="destructive"
                  className="flex-1 gap-1"
                  onClick={(e) => {
                    e.preventDefault();
                    handleDelete();
                  }}
                  disabled={isUploading}
                >
                  <Check className="h-4 w-4" />
                  حذف
                </Button>
              </div>
            ) : (
              <Button
                variant="destructive"
                className="w-full"
                onClick={(e) => {
                  e.preventDefault();
                  setShowDeleteConfirm(true);
                }}
                disabled={isUploading}
              >
                <Trash2 className="ml-2 h-4 w-4" />
                حذف فاویکون
              </Button>
            )}
          </div>
        )}

        {error && <p className="mt-2 text-sm text-red-500">{error}</p>}
      </div>
    </div>
  );
};

export default FaviconUploader;
