import { Loader2 } from "lucide-react";
import React from "react";

const NormalSpinner = () => {
  return (
    <div>
      <Loader2 />
    </div>
  );
};

export default NormalSpinner;
