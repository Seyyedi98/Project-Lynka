import React from "react";

const EditorItemsTrigger = () => {
  return <div>Open Items</div>;
};

export default EditorItemsTrigger;
