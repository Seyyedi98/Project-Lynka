import { useSelector } from "react-redux";
import PreviewPageElements from "./preview-elements-renderer";
import PreviewPageHero from "./preview-hero-renderer";
import { cn } from "@/lib/utils";
import parseJson from "@/utils/parseJSON";
import getImageAddress from "@/utils/get-image-address";
import { useMediaQuery } from "@/hooks/useMediaQuery";

const PreviewPageContainer = () => {
  const theme = useSelector((state) => state.page.theme);
  const isDesktop = useMediaQuery("(min-width: 600px)");

  const backgroundImageUrl =
    theme.backgroundImage && parseJson(theme.backgroundImage)?.key === "no_key"
      ? isDesktop
        ? parseJson(theme.backgroundImage)?.url.replace("mobile", "desktop")
        : parseJson(theme.backgroundImage)?.url // images form public folder
      : getImageAddress(parseJson(theme.backgroundImage)?.key); // images from bucket

  const colorBgStyle = {
    backgroundColor: theme.backgroundColor,
    background: theme.backgroundColor,
    backgroundSize: theme.backgroundType === "gradient" ? "200% 200%" : "cover",
  };
  const imageBgStyle = {
    backgroundImage:
      theme.backgroundType === "image" && `url(${backgroundImageUrl})`,
    backgroundPosition: "center",
    backgroundSize: "cover",
    backgroundRepeat: "no-repeat",
  };

  return (
    <div
      style={
        theme.backgroundType === "color" ||
        theme.backgroundType === "gradient" ||
        theme.backgroundType === "pattern"
          ? colorBgStyle
          : imageBgStyle
      }
      className={cn(
        `flex h-svh w-full flex-col items-center justify-start overflow-y-scroll pb-20 [scrollbar-width:none]`,
        theme.isBackgroundAnimated &&
          theme.backgroundType === "gradient" &&
          "animate-bg-move",
      )}
    >
      {/* <div className="h-full w-full"> */}

      <div className="w-full">
        <PreviewPageHero />
      </div>

      <section className="mt-2 flex w-full max-w-[400px] flex-col items-center justify-start gap-4 px-4">
        <PreviewPageElements />
      </section>
      {/* </div> */}
    </div>
  );
};

export default PreviewPageContainer;
