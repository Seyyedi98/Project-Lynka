import Link from "next/link";
import React from "react";

const NotFound = () => {
  return (
    <div className="flex h-svh w-full flex-col items-center justify-center gap-4">
      <p className="text-4xl">صفحه پیدا نشد!</p>
      <Link href="../">برگشت به صفحه اصلی</Link>
    </div>
  );
};

export default NotFound;
