const EditorLayout = ({ children }) => {
  return <div className="h-svh w-dvw bg-black">{children}</div>;
};

export default EditorLayout;
