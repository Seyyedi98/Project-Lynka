import React from "react";

const WhatsNew = () => {
  return <div>WhatsNew</div>;
};

export default WhatsNew;
