import React from "react";

const Purchase = () => {
  return <div>Purchase</div>;
};

export default Purchase;
