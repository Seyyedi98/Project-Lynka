import React from "react";

const ShopPanel = () => {
  return <div className="grid place-items-center">ShopPanel</div>;
};

export default ShopPanel;
