import React from "react";

const NotificationsPanel = () => {
  return <div>NotificationsPanel</div>;
};

export default NotificationsPanel;
