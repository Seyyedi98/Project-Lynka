import React from "react";

const Transactions = () => {
  return <div className="grid place-items-center">ShopPanel</div>;
};

export default Transactions;
