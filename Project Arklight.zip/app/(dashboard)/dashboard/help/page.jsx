import React from "react";

const HelpPage = () => {
  return <div>HelpPage</div>;
};

export default HelpPage;
