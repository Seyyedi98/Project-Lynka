import React from "react";

const AnalyticsPanel = () => {
  return <div>AnalyticsPanel</div>;
};

export default AnalyticsPanel;
