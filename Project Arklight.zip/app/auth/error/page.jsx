import ErrorCard from "@/app/_components/common/message/error-card";
import React from "react";

const AuthErrorPage = () => {
  return <ErrorCard />;
};

export default AuthErrorPage;
