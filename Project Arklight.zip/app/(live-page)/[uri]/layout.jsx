const PreviewLayout = ({ children }) => {
  return <div className="h-svh w-full bg-background">{children}</div>;
};

export default PreviewLayout;
